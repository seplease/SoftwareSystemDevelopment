package springidol;

public interface Poem {
	public void recite();
}
