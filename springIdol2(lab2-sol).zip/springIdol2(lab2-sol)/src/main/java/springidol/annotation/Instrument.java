package springidol.annotation;

public interface Instrument {
	public void play();
}
