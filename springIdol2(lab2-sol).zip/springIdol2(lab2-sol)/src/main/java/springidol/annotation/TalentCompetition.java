package springidol.annotation;

public interface TalentCompetition {
	public void run();
}
