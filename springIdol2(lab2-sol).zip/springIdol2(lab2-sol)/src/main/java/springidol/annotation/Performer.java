package springidol.annotation;

public interface Performer {
	public void perform() throws PerformanceException;
}
