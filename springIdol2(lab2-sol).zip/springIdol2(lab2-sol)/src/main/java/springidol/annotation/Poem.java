package springidol.annotation;

public interface Poem {
	public void recite();
}
