package springidol;

public class Piano implements Instrument {
	public Piano() {}

	public void play() {
		System.out.println("PLANK PLANK PLANK~~");
	}
}
