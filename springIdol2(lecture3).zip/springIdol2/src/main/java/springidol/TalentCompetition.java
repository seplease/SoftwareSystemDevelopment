package springidol;

public interface TalentCompetition {
	public void run();
}
