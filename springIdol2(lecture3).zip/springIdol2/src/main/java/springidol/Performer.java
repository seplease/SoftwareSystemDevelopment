package springidol;

public interface Performer {
	public void perform() throws PerformanceException;
}
