package springidol.annotation;

public class Harmonica implements Instrument {
	public Harmonica() {
	}

	public void play() {
		System.out.println("HUM HUM HUM~~");
	}
}
