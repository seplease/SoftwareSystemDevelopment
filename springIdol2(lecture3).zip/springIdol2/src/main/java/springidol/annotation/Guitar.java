package springidol.annotation;

public class Guitar implements Instrument {
	public Guitar() {
	}

	public void play() {
		System.out.println("STRUM STRUM STRUM~~");
	}
}
